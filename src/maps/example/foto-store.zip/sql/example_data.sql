INSERT INTO `stores` (`id`, `name`, `address`, `zip`, `city`, `state`, `country`, `url`, `latitude`, `longitude`)
VALUES
  (1,'My store #1','12 Avenue Aristide Briand','35000','Rennes',NULL,'France','http://www.example.com/store1',48.1105,-1.66476),
  (2,'My store #2','34 Boulevard de Metz','35000','Rennes',NULL,'France','http://www.example.com/store2',48.1166,-1.65817),
  (3,'My store #3','123 Boulevard de Ménilmontant','75020','Paris',NULL,'France','http://www.example.com/store3',48.8659,2.38373),
  (4,'My store #4','35 rue Étienne Dollet','75020','Paris',NULL,'France','http://www.example.com/store4',48.8683,2.38558),
  (5,'My store #5','2 boulevard Saint-Martin','75003','Paris',NULL,'France','http://www.example.com/store5',48.8685,2.35873);
  