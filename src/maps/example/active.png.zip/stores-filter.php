<?php

/**
 * This script is an example PHP script that shows you what can
 * be called by the store locator plugin. It is very simple, but
 * should help you understand how you can integrate the plugin
 * in YOUR application.
 *
 * We suppose here that you have a working MySQL server (provide
 * its connection information below), which contains a database
 * (storelocator), which itself contains a table, "stores". See
 * the "create_table.sql" and "example_data.sql" to reproduce this
 * example on your system.
 */

// Insert here the information to connect to your MySQL server.
$db_host = "localhost";
$db_user = "k4706840_febri";
$db_pass = "febri123";
$db_name = "k4706840_etools";
$distributor = isset($_GET['distributor']) ? $_GET['distributor'] : '';
if ($distributor!="")
{$distributor = "AND distributor_code in (".$distributor.")"; }
else
{$distributor = ""; 
}


$channel = isset($_GET['channel']) ? $_GET['channel'] : '';
if ($channel!="")
{$channel = "AND channel_code in ('".$channel."')"; }
else
{$channel = ""; 
}

$motorist = isset($_GET['motorist']) ? $_GET['motorist'] : '';
if ($motorist!="")
{$motorist = "AND motorist_code in ('".$motorist."')"; }
else
{$motorist = ""; 
}


$day = isset($_GET['day']) ? $_GET['day'] : '';
if ($day!="")
{
	$day = "AND day_visit in ('monday','tuesday')"; }
else
{
	$day = ""; 
}




$month = isset($_GET['month']) ? $_GET['month'] : '';
$transaction_month = isset($_GET['transaction_month']) ? $_GET['transaction_month'] : '';

// Response is always JSON.
header('Content-type: application/json');

// Parameters
$lat = floatval("-6.203277");
$lng = floatval("106.845984");
if( !$lat || !$lng )
{
	$protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');
	header("$protocol 400 Bad Request");
	die(json_encode(array('error' => "Wrong values for 'lat' and/or 'lng' parameters.")));
}

// SQL request. The complexe part is here to compute the distance
// between the position passed in the parameters and each store.
$product = isset($_GET['product']) ? $_GET['product'] : '';

if($product=="")
{
	
$sql = "SELECT id_store,latitude,longitude,customer_name,address,districts,customer_status,urutan_motorist,channel_code,channel_name,motorist_code,foto_toko,motorist_name,distributor_name,customer_code,day_visit,
			((ACOS(SIN($lat * PI() / 180) * SIN(latitude * PI() / 180) + COS($lat * PI() / 180) * COS(latitude * PI() / 180) * COS(($lng - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515) AS distance
		FROM store WHERE status_latitude = 'yes' ".$distributor." ".$motorist." ".$channel." ".$day." 
		HAVING distance <= 10
		ORDER BY distance ASC";
}
else
{
	if($transaction_month=="yes")
	{
		$product = isset($_GET['product']) ? $_GET['product'] : '';
		if($product!="")
		{
			$query_product = "AND product_orders.id_product in ('".$product."')" ;
		}

		$mo =	date('m');
		$year = date('y');
		if($month!="")
		{		
			$sql = "SELECT *,
			((ACOS(SIN($lat * PI() / 180) * SIN(latitude * PI() / 180) + COS($lat * PI() / 180) * COS(latitude * PI() / 180) * COS(($lng - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515) AS distance
			FROM store LEFT JOIN product_orders ON product_orders.customer_code = store.customer_code WHERE status_latitude = 'yes' ".$distributor." ".$motorist." ".$channel." ".$day." ".$query_product." AND product_orders.date between '".$year.'-'.$month.'-01 00:00:00'."' AND  '".$year.'-'.$month.'-31 23:59:59'."'
			HAVING distance <= 10
			ORDER BY distance ASC";
		}
		else
		{ 
			$sql = "SELECT *,
			((ACOS(SIN($lat * PI() / 180) * SIN(latitude * PI() / 180) + COS($lat * PI() / 180) * COS(latitude * PI() / 180) * COS(($lng - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515) AS distance
			FROM store LEFT JOIN product_orders ON product_orders.customer_code = store.customer_code WHERE status_latitude = 'yes' ".$distributor." ".$motorist." ".$channel." ".$day." ".$query_product." AND product_orders.date between '".$year.'-'.$mo.'-01 00:00:00'."' AND  '".$year.'-'.$mo.'-31 23:59:59'."'
			HAVING distance <= 10
			ORDER BY distance ASC";	
		}
	}
	else
	{
		$product = isset($_GET['product']) ? $_GET['product'] : '';
		if($product!="")
		{
			$query_product = "AND product_orders.id_product not in ('".$product."')" ;
		}
		
		$mo =	date('m');
		$year = date('y');
		if($month!="")
		{		
			$sql = "SELECT *,
			((ACOS(SIN($lat * PI() / 180) * SIN(latitude * PI() / 180) + COS($lat * PI() / 180) * COS(latitude * PI() / 180) * COS(($lng - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515) AS distance
			FROM store LEFT JOIN product_orders ON product_orders.customer_code = store.customer_code WHERE status_latitude = 'yes' ".$distributor." ".$motorist." ".$channel." ".$day." ".$query_product." AND product_orders.date between '".$year.'-'.$month.'-01 00:00:00'."' AND  '".$year.'-'.$month.'-31 23:59:59'."'
			HAVING distance <= 10
			ORDER BY distance ASC";
		}
		else
		{
			
			$sql = "SELECT *,
			((ACOS(SIN($lat * PI() / 180) * SIN(latitude * PI() / 180) + COS($lat * PI() / 180) * COS(latitude * PI() / 180) * COS(($lng - longitude) * PI() / 180)) * 180 / PI()) * 60 * 1.1515) AS distance
			FROM store LEFT JOIN product_orders ON product_orders.customer_code = store.customer_code WHERE status_latitude = 'yes' ".$distributor." ".$motorist." ".$channel." ".$day." ".$query_product." AND product_orders.date between '".$year.'-'.$mo.'-01 00:00:00'."' AND  '".$year.'-'.$mo.'-31 23:59:59'."'
			HAVING distance <= 10
			ORDER BY distance ASC";	
		}
		
	}
}


// Connexion to MySQL server.
$mysqli = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if( !$mysqli ) {
	$protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');
	header("$protocol 500 Internal Server Error");
	die(json_encode(array('error' => "Database connection error.")));
}

// Setting up the data encoding as UTF-8.
mysqli_set_charset($mysqli, 'utf8');

// We keep the stores in this array.
$nearbyStores = array();

// Execution of the SELECT query.
$res = @mysqli_query($mysqli, $sql);
if( $res ) {

	// For each stores...
	while( $store = @mysqli_fetch_assoc($res) ) {

		// We construct two strings containing the distance in kilometers and miles.
		$store['distance-kilometers'] = round($store['distance']) . ' km';
		$store['distance-miles'] = round($store['distance'] / 1.6) . ' mi';

		// We add the store to the result array.
		$nearbyStores[] = $store;

	}
}

// We return the stores in JSON format.
echo json_encode($nearbyStores);
