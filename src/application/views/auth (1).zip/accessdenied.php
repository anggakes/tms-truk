<div class="row">
<div class="col-lg-12">
                  <div class="content-panel" style="min-height:500px;">
                		<div class="panel-body">
                        <?php echo $data; ?>
                        </div>
                          
                          
                    </div>
                     
                  </div>
</div><!-- col-lg-12-->  
</div><!-- row -->



