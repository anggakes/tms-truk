<section class="sidebar">
          <!-- Sidebar user panel -->
         <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url(); ?>assets_theme/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $data_account[0]['username']; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
         
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i>
                <span>Dashboard</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                 <li><a href="<?php echo base_url()."index.php/motorist/dailySummaryMotorist/"; ?>"><i class="fa fa-circle-o"></i>Target Daily Sales</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/dailyCallStrikeSidebar/"; ?>"><i class="fa fa-circle-o"></i>Daily CallStrike Motorist</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/monthlySummaryMotorist/"; ?>"><i class="fa fa-circle-o"></i>Target Monthly Sales</a></li>
				 <li><a href="<?php echo base_url()."index.php/absence/summaryAbsence/"; ?>"><i class="fa fa-circle-o"></i>Motorist Absence</a></li>
				 <li><a href="<?php echo base_url()."index.php/order/"; ?>"><i class="fa fa-circle-o"></i>Invoice Details</a></li>
                 <li><a href="<?php echo base_url()."index.php/order/monthlyOrder"; ?>"><i class="fa fa-circle-o"></i>Monthly Invoice Details</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/journeyPlanMotorist/"; ?>"><i class="fa fa-circle-o"></i>Journey plan motorist</a></li>
				 <li><a href="<?php echo base_url()."index.php/stock/summarystock/"; ?>"><i class="fa fa-circle-o"></i>Daily Stock Motorist</a></li>
                 <li><a href="<?php echo base_url()."index.php/motorist/swicthingMotoristStore/"; ?>"><i class="fa fa-circle-o"></i>Additional Outlet</a></li>
                 <li><a href="<?php echo base_url()."index.php/motorist/swicthingMotoristNoo/"; ?>"><i class="fa fa-circle-o"></i>Outlet Switching</a></li>
                 <li><a href="<?php echo base_url()."index.php/store/outletSTT/"; ?>"><i class="fa fa-circle-o"></i>Outlet STT</a></li>
              </ul>
            </li>
			<?php if($data_account[0]['code']!="218000"){ ?>
            <li class="treeview">
              <a href="<?php echo site_url(""); ?>">
                <i class="fa fa-bar-chart"></i> <span>Chart</span> 
              </a>
                <ul class="treeview-menu">
                 <?php if($data_account[0]['user_type']=="Ado"){ ?>
                 <li><a href="<?php echo base_url()."index.php/chart_motorist/"; ?>"><i class="fa fa-circle-o"></i>Register outlet channel</a></li>
				 <li><a href="<?php echo base_url()."index.php/chart_motorist/outletActive/"; ?>"><i class="fa fa-circle-o"></i>Active & Register outlet</a></li>
				 <li><a href="<?php echo base_url()."index.php/chart_motorist/callMotorist/"; ?>"><i class="fa fa-circle-o"></i>Call & Effective Call</a></li>
				 <li><a href="<?php echo base_url()."index.php/chart_motorist/sttMotorist/"; ?>"><i class="fa fa-circle-o"></i>Stt Performance</a></li>
             	 <?php } ?>
                 
                 <?php if($data_account[0]['user_type']=="Administrator"){ ?>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/"; ?>"><i class="fa fa-circle-o"></i>Outlet Contribution</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/registerOutlet/"; ?>"><i class="fa fa-circle-o"></i>Register Vs Active</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/brandContribution/"; ?>"><i class="fa fa-circle-o"></i>Brand Contribution</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/loyaltyProgram/"; ?>"><i class="fa fa-circle-o"></i>Loyalty Program</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/sttAchievement/"; ?>"><i class="fa fa-circle-o"></i>STT Achievement</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/motoristPerformanceStt/"; ?>"><i class="fa fa-circle-o"></i>Performance STT</a></li>
                 <li><a href="<?php echo base_url()."index.php/chart_admin/motoristPerformanceTracking/"; ?>"><i class="fa fa-circle-o"></i>Motorist Achievement</a></li>
                 
             	 <?php } ?>
              </ul>
              
            </li>
			<?php } ?>
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-database"></i>
                <span>Master Data</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
				<?php if($data_account[0]['user_type']=="Administrator"){ ?>
                 <li><a href="<?php echo site_url("product/product"); ?>"><i class="fa fa-circle-o"></i>Data Product</a></li>
				 <li><a href="<?php echo site_url("distributor/distributor"); ?>"><i class="fa fa-circle-o"></i>Data Distributor</a></li>
				 <li><a href="<?php echo site_url("channel/channel"); ?>"><i class="fa fa-circle-o"></i>Data Channel</a></li>
				 <?php }?>
				 <li><a href="<?php echo site_url("motorist/motorist"); ?>"><i class="fa fa-circle-o"></i>Data Motorist</a></li>
				 <li><a href="<?php echo site_url("store"); ?>"><i class="fa fa-circle-o"></i>Data Store</a></li>
                 <li><a href="<?php echo site_url("store/stokpoint"); ?>"><i class="fa fa-circle-o"></i>Data Stock Point</a></li>
				 <li><a href="<?php echo site_url("noo"); ?>"><i class="fa fa-circle-o"></i>Data Noo</a></li>
              </ul>
            </li>
			
			
			<?php if($data_account[0]['code']!="218000"){ ?>
			<li class="treeview">
              <a href="#">
                <i class="fa fa-map"></i>
                <span>Maps</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                 <li><a href="<?php echo base_url()."index.php/store/filterstore/"; ?>"><i class="fa fa-circle-o"></i>Filter Maps</a></li>
              </ul>
            </li>
            <?php } ?>
           
            <li class="treeview">
              <a href="#">
                <i class="fa fa-briefcase "></i>
                <span>DSOR</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                 <li><a href="<?php echo base_url()."index.php/motorist/dailySummaryMotoristAdo/"; ?>"><i class="fa fa-circle-o"></i>Summary Productivity</a></li>
                 <li><a href="<?php echo base_url()."index.php/motorist/dailySalesMotoristAdo/"; ?>"><i class="fa fa-circle-o"></i>Summary Penjualan</a></li>
              </ul>
            </li>
			
			
			
            
            
            
            
            
           
            
            <li class="reeview">
              <a href="<?php echo site_url("auth/logout"); ?>">
                <i class="fa fa-sign-out"></i> <span>Logout</span> 
              </a>
            </li>
           
          </ul>
        </section>
        <!-- /.sidebar -->