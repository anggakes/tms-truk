 <section class="content-header">
          <h1>
            Dashboard
            <small>Preview of UI elements</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">UI</a></li>
            <li class="active">General</li>
          </ol>
        </section>
  
  <style>
  chart-1{
	  width:100% !important;}
	 .highcharts-container{
		width:100% !important; }
  </style>
  
   <section class="content">
          <!-- COLOR PALETTE -->
          <div class="box sms box-default color-palette-box">
            <div class="box-header with-border">
              <h3 class="box-title"><i class="fa fa-tag"></i> Welcome</h3>
            </div>
            <div class="box-body">
			 
            Selamat Datang di Backend Etools,
        
            
            </div>
      </section>

<script>
var chart = new Highcharts.Chart({
    chart: {
        renderTo: 'chart-1',
        defaultSeriesType: 'column',
        borderWidth: 1,
        borderColor: '#ccc',
		color:'#f90',
        marginLeft: 110,
        marginRight: 50,
       //fer backgroundColor:'#eee',
        //plotBackgroundColor:'#fff',
    },
    title: {
        text: 'Trend Outlet Active'
    },
    legend: {

    },
    tooltip: {
    },
    plotOptions: {
        series: {
            shadow: false,
        }
    },
    xAxis: {
        categories: ['Jan-16', 'Feb-16', 'Mar-16', 'Apr-16', 'May-16', 'Jun-16', 'Jul-16', 'Aug-16', 'Sep-16', 'Oct-16', 'Nov-16', 'Dec-16'],
        lineColor: '#999',
        lineWidth: 1,
        tickColor: '#666',
        tickLength: 3,
        title: {
            style: {
                color: '#000'
            }

        }
    },
    yAxis: [{
        min: 0,
        //endOnTick:false,
        //lineColor:'#999',
        lineWidth: 1
        //tickColor:'#666',
        //tickWidth:1,
        //tickLength:3,
        //gridLineColor:'#ddd',
        /* title:{
            text:'Y Axis Title',
            rotation:0,
            margin:50,
            style:{
                color:'#000'
            }
        }*/
    }, {
        title: {
            text: ''
        },
        //alignTicks:false,
        gridLineWidth: 0,
        lineColor: '#999',
        lineWidth: 1,
        tickColor: '#666',
        tickWidth: 1,
        tickLength: 3,
        endOnTick: false,
        opposite: true,
        linkedTo: 0
    }],
    series: [{
        //yAxis:0,
		name: 'Total',
		color:'#70ad47',
        data: [0, 0, 0, 0, 0, 0, 0, <?php print $data_trend_active_outlet_aug; ?>, <?php print $data_trend_active_outlet_sept; ?>, 0, 0, 0]
    }, {
        type: 'line',
        name: 'SUM',
		color:'#5b9bd5',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'WJR',
		color: '#ed7d31',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, <?php print $data_trend_active_outlet_aug; ?>, <?php print $data_trend_active_outlet_sept; ?>, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'CJR',
		color: '#a5a5a5',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'EJR',
		color: '#ffc000',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'SUL',
		color: '#4472c4',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    }]
});
</script>

<script>

  // Build the chart
        $('#chart-2').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Kontribusi Outlet Active'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                colorByPoint: true,
                data: [{
                    name: 'SUM',
					color:'#5b9bd5',
                    y:0
                }, {
                    name: 'WJR-<?php print $data_kon_aug[0]['id_product_order']; ?>,',
                    y: <?php print $data_kon_aug[0]['id_product_order']; ?>,
					color: '#ed7d31',
                    sliced: true,
                    selected: true
                }, {
                    name: 'CJR',
                    color: '#a5a5a5',
					y: 0
                }, {
                    name: 'EJR',
					color: '#ffc000',
                    y: 0
                }, {
                    name: 'SUL',
					color: '#4472c4',
                    y: 0
                }]
            }]
        });
</script>



<script>
var chart = new Highcharts.Chart({
    chart: {
        renderTo: 'chart-3',
        defaultSeriesType: 'column',
        borderWidth: 1,
        borderColor: '#ccc',
		color:'#f90',
        marginLeft: 110,
        marginRight: 50,
       //fer backgroundColor:'#eee',
        //plotBackgroundColor:'#fff',
    },
    title: {
        text: 'Trend STT'
    },
    legend: {

    },
    tooltip: {
    },
    plotOptions: {
        series: {
            shadow: false,
        }
    },
    xAxis: {
        categories: ['Jan-16', 'Feb-16', 'Mar-16', 'Apr-16', 'May-16', 'Jun-16', 'Jul-16', 'Aug-16', 'Sep-16', 'Oct-16', 'Nov-16', 'Dec-16'],
        lineColor: '#999',
        lineWidth: 1,
        tickColor: '#666',
        tickLength: 3,
        title: {
            style: {
                color: '#000'
            }

        }
    },
    yAxis: [{
        min: 0,
        //endOnTick:false,
        //lineColor:'#999',
        lineWidth: 1
        //tickColor:'#666',
        //tickWidth:1,
        //tickLength:3,
        //gridLineColor:'#ddd',
        /* title:{
            text:'Y Axis Title',
            rotation:0,
            margin:50,
            style:{
                color:'#000'
            }
        }*/
    }, {
        title: {
            text: ''
        },
        //alignTicks:false,
        gridLineWidth: 0,
        lineColor: '#999',
        lineWidth: 1,
        tickColor: '#666',
        tickWidth: 1,
        tickLength: 3,
        endOnTick: false,
        opposite: true,
        linkedTo: 0
    }],
    series: [{
        //yAxis:0,
		name: 'Total',
		color:'#70ad47',
        data: [0, 0, 0, 0, 0, 0, 0,<?php print $data_stt_outlet_aug[0]['price_total']; ?>, <?php print $data_stt_outlet_sep[0]['price_total']; ?>,, 0, 0, 0]
    }, {
        type: 'line',
        name: 'SUM',
		color:'#5b9bd5',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'WJR',
		color: '#ed7d31',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, <?php print $data_stt_outlet_aug[0]['price_total']; ?>, <?php print $data_stt_outlet_sep[0]['price_total']; ?>,, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'CJR',
		color: '#a5a5a5',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'EJR',
		color: '#ffc000',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    },
	{
        type: 'line',
        name: 'SUL',
		color: '#4472c4',
        //yAxis:0,
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    }]
});
</script>



<script>

  // Build the chart
        $('#chart-4').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Kontribusi STT'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
           series: [{
                colorByPoint: true,
                data: [{
                    name: 'SUM',
					color:'#5b9bd5',
                    y:0
                }, {
                    name: 'WJR-<?php print $data_kon_stt_aug[0]['price_total']; ?>',
                    y: <?php print $data_kon_stt_aug[0]['price_total']; ?>,
					color: '#ed7d31',
                    sliced: true,
                    selected: true
                }, {
                    name: 'CJR',
                    color: '#a5a5a5',
					y: 0
                }, {
                    name: 'EJR',
					color: '#ffc000',
                    y: 0
                }, {
                    name: 'SUL',
					color: '#4472c4',
                    y: 0
                }]
            }]
        });
</script>


<script>

$("#select-regional").pqSelect({
   multiplePlaceholder: 'Select Regional',
   checkbox: true //adds checkbox to options    
   }).on("change", function(evt) {
      var val = $(this).val();
    })

$("#select-jenis-motorist").pqSelect({
   multiplePlaceholder: 'Select Jenis Motorist',
   checkbox: true //adds checkbox to options    
   }).on("change", function(evt) {
      var val = $(this).val();
    })




$("#select-product").pqSelect({
   multiplePlaceholder: 'Select Product',
   checkbox: true //adds checkbox to options    
   }).on("change", function(evt) {
      var val = $(this).val();
    })



</script>
