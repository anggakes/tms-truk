 <!-- HEADER -->
 <section class="content-header">
          <h1>
            Product
            <small>Product of E-tools</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo BASE_URL(); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="<?php echo BASE_URL()."product"; ?>"><i class="fa fa-dashboard"></i>Product</a></li>
          </ol>
        </section>
  
  
   <!-- Content -->
   <section class="content">
          <div class="box sms box-default color-palette-box">
            <div class="box-header with-border">
              <h3 class="box-title"><i class="fa fa-table"></i> Table Product</h3>
            </div>
            <div class="box-body">
            <?php $message_success = $this->session->flashdata('message_success');
					 	if($message_success!="")
						{
					  ?>
                     <div class="alert alert-success"><?php echo $message_success; ?></div>
                     <?php } ?>
                     <?php $message_failed = $this->session->flashdata('message_failed');
					 	if($message_failed!="")
						{
					  ?>
                     <div class="alert alert-danger"><?php echo $message_failed; ?></div>
                     <?php } ?>
            <div id="wrapper-table">
            <?php
			$search = isset($_GET['search']) ? $_GET['search'] : '';
			function convert_price($price)
			{
				echo "Rp. ".number_format($price, 0 , '' , '.' );		
					}
			?>
            <div id="wrapper-console" class="clearfix">
                <div id="wrapper-search">
                             <form action="<?php echo base_url()."index.php/product" ?>" method="get">
                             <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash();?>" />
                                <input type="text" id="search" name="search" placeholder="Search..."  value="<?php echo $search; ?>" />
                                <input type="submit" id="submit"  value="Search"/>
                                <?php if($search!="")
								{?>
                                <a href="<?php echo base_url()."index.php/product" ?>" id="clear-search">Clear Search</a>
                                <?php } ?>
                             </form>
                </div>
                <div id="wrapper-button" class="clearfix">
                	<a href="<?php echo base_url()."index.php/product/exportProduct" ?>" class="button orange-button">
                    	Export Product
                    </a>
                    
                    <a href="<?php echo base_url()."index.php/product/addProduct" ?>" class="button green-button">
                    	Add Product
                    </a>
                    
                    <a href="<?php echo base_url()."index.php/product/importProduct" ?>" class="button blue-button">
                    	Import Product
                    </a>
                </div>
                </div>
            <div id="wrapper-console" class="clearfix"> 
            <div class="grid_4 height400">                  
           	<table id="myTable04" class="fancyTable table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>ID Product</th>
                        <th>Product Code</th>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>SKU</th>
                        <th>SKU Font End</th>
                        <th>Unit</th>
                        <th>Price Cs</th>
                        <th>Price Pcs</th>
                        <th>Type</th>
                        <th>Action</th>
                      </tr>
                    </thead>
             		<tbody>
                    <?php foreach($data_product as $data_product) {?>
                    <tr>
                    	<td><?php echo $data_product->id_product; ?></td>
                        <td><?php echo $data_product->brand; ?></td>
                        <td><?php echo $data_product->product_code; ?></td>
                        <td><?php echo $data_product->category; ?></td>
                        <td><?php echo $data_product->sku; ?></td>
                        <td><?php echo $data_product->sku_front_end; ?></td>
                        <td><?php echo $data_product->unit; ?></td>
                        <td><?php echo convert_price($data_product->price_cs); ?></td>
                        <td><?php echo convert_price($data_product->price_pcs); ?></td>
                        <td><?php echo $data_product->type; ?></td>
                        <td><a href="<?php echo base_url()."index.php/product/editProduct/".$data_product->id_product ?>">Edit</a> | <a href="<?php echo base_url()."index.php/product/deleteProduct/".$data_product->id_product ?>">Delete</a></td>
                        </tr>
                    <?php }?>
                    </tbody>       
             </table>
             </div>
             
            		  <div class="pagination page">  
                     <?php  echo $this->pagination->create_links(); ?>
                     </div>
                    
            
           </div>
            </div>
            
            </div>
      </section>

