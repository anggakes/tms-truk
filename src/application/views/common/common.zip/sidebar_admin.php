<section class="sidebar">
          <!-- Sidebar user panel -->
         <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url(); ?>assets_theme/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $data_account[0]['username']; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
         
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i>
                <span>Dashboard</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                 <li><a href="<?php echo base_url()."index.php/motorist/dailySummaryMotorist/"; ?>"><i class="fa fa-circle-o"></i>Target Daily Sales</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/dailyCallStrikeSidebar/"; ?>"><i class="fa fa-circle-o"></i>Daily CallStrike Motorist</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/monthlySummaryMotorist/"; ?>"><i class="fa fa-circle-o"></i>Monthly Daily Sales</a></li>
				 <li><a href="<?php echo base_url()."index.php/absence/summaryAbsence/"; ?>"><i class="fa fa-circle-o"></i>Motorist Absence</a></li>
				 <li><a href="<?php echo base_url()."index.php/order/"; ?>"><i class="fa fa-circle-o"></i>Invoice Details</a></li>
				 <li><a href="<?php echo base_url()."index.php/motorist/journeyPlanMotorist/"; ?>"><i class="fa fa-circle-o"></i>Journey plan motorist</a></li>
				 <li><a href="<?php echo base_url()."index.php/stock/summarystock/"; ?>"><i class="fa fa-circle-o"></i>Daily Stock Motorist</a></li>
              </ul>
            </li>
			
            <li class="treeview">
              <a href="<?php echo site_url(""); ?>">
                <i class="fa fa-bar-chart"></i> <span>Chart</span> 
              </a>
            </li>
			
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-database"></i>
                <span>Master Data</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
				<?php if($data_account[0]['user_type']=="Administrator"){ ?>
                 <li><a href="<?php echo site_url("product/product"); ?>"><i class="fa fa-circle-o"></i>Data Product</a></li>
				 <li><a href="<?php echo site_url("distributor/distributor"); ?>"><i class="fa fa-circle-o"></i>Data Distributor</a></li>
				 <li><a href="<?php echo site_url("channel/channel"); ?>"><i class="fa fa-circle-o"></i>Data Channel</a></li>
				 <?php }?>
				 <li><a href="<?php echo site_url("motorist/motorist"); ?>"><i class="fa fa-circle-o"></i>Data Motorist</a></li>
				 <li><a href="<?php echo site_url("store"); ?>"><i class="fa fa-circle-o"></i>Data Store</a></li>
				  <li><a href="<?php echo site_url("noo"); ?>"><i class="fa fa-circle-o"></i>Data Noo</a></li>
              </ul>
            </li>
			
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-map"></i>
                <span>Maps</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                 <li><a href="<?php echo base_url()."index.php/store/filterstore/"; ?>"><i class="fa fa-circle-o"></i>Filter Maps</a></li>
              </ul>
            </li>
			
			
			
            
            
            
            
            
           
            
            <li class="reeview">
              <a href="<?php echo site_url("auth/logout"); ?>">
                <i class="fa fa-sign-out"></i> <span>Logout</span> 
              </a>
            </li>
           
          </ul>
        </section>
        <!-- /.sidebar -->