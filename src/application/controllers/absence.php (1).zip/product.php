<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Controller {

	function __construct()  {
 		parent::__construct();
			$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
			$this->load->model('model_account_master');
			$this->load->model('model_product');
			$this->load->library('tank_auth');
			
	}
	
	

	public function index()
	{
		
			date_default_timezone_set('Asia/Jakarta');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['see_product']=='yes')
			{	
			$this->load->library('table');
			$this->load->library('pagination');
			$search = isset($_GET['search']) ? $_GET['search'] : '';
			$jumlah= $this->model_product->countProduct($search);
			$config['base_url'] = base_url().'index.php/product/';
			$config['total_rows'] = $jumlah;
			$config['first_link'] = 'First';
			$config['last_link'] = 'End';
			$config['next_link'] = 'Next';
			$config['prev_link'] = 'Previous';
			$config['per_page'] = 100; 	
			
			$dari = $this->uri->segment('3');
			$data = $this->model_product->dataProduct($config['per_page'],$dari,$search);
			$this->pagination->initialize($config);
			
		
			$comp = array(
				
				'title' => ' Product',
				'content' => $this->load->view('product',array('data_product'=>$data,'search'=>$search),true),
				'sidebar' => $this->html_sidebar()
			
			);
			
			$this->load->view("common/common",$comp);
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	public function mtdProductSales()
	{
		
			date_default_timezone_set('Asia/Jakarta');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['see_product']=='yes')
			{	
			
			$this->load->library('table');
			$this->load->library('pagination');
			$search = isset($_GET['search']) ? $_GET['search'] : '';
			$jumlah= $this->model_product->countMtdSales($search,$user_role,$code_role);
			$config['base_url'] = base_url().'index.php/product/';
			$config['total_rows'] = $jumlah;
			$config['first_link'] = 'First';
			$config['last_link'] = 'End';
			$config['next_link'] = 'Next';
			$config['prev_link'] = 'Previous';
			$config['per_page'] = 100; 	
			
			$dari = $this->uri->segment('3');
			$data = $this->model_product->MtdSales($config['per_page'],$dari,$search,$user_role,$code_role);
			$this->pagination->initialize($config);
			
		
			$comp = array(
				
				'title' => ' Product',
				'content' => $this->load->view('data-mtd-sales',array('data_product'=>$data,'search'=>$search),true),
				'sidebar' => $this->html_sidebar()
			
			);
			
			$this->load->view("common/common",$comp);
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	public function addProduct()
	{
		
			date_default_timezone_set('Asia/Jakarta');
			ini_set('memory_limit', '-1');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['add_product']=='yes')
			{
				
			$this->load->helper('form');
			$this->load->helper('url');
			$this->load->library('form_validation');
		
			$this->form_validation->set_rules('product_code','Product Code','required');
			$this->form_validation->set_rules('brand','Brand','required');
			$this->form_validation->set_rules('category','Category','required');
			$this->form_validation->set_rules('product_name','Product Name','required');
			$this->form_validation->set_rules('product_name_front','Product Name Front','required');
			$this->form_validation->set_rules('unit','Unit','required');
			$this->form_validation->set_rules('price_cs','Price cs','required');
			$this->form_validation->set_rules('price_pcs','Price pcs','required');
			$this->form_validation->set_rules('type_motorist','Type Motorist','required');
			
			if($this->form_validation->run()==FALSE){
					
					$data = array ("");
					$comp = array(
						
						'title' => ' Add Product',
						'content' => $this->load->view('add-product',array('data'=>$data),true),
						'sidebar' => $this->html_sidebar()
					
					);
					
					$this->load->view("common/common",$comp);
			}
			
			else
			{
				// Get Variable Post
				$product_code = $_POST['product_code'];
				$brand = $_POST['brand'];
				$category = $_POST['category'];
				$product_name = $_POST['product_name'];
				$product_name_front = $_POST['product_name_front'];
				$unit = $_POST['unit'];
				$price_cs = $_POST['price_cs'];
				$price_pcs = $_POST['price_pcs'];
				$type_motorist = $_POST['type_motorist'];
				
				$data_insert = array(
				
				"product_code" => $product_code,
				"brand" => $brand,
				"category" => $category,
				"sku" => $product_name,
				"sku_front_end" => $product_name_front,
				"unit" => $unit,
				"price_cs" => $price_cs,
				"price_pcs" => $price_pcs,
				"type" => $type_motorist

				);
				
				//Check Product Apakah sudah ada dengan kode produk dan type motorist yang sama
				$check = $this->model_product->getProduct("WHERE product_code = '".$product_code."' AND type = '".$type_motorist."' ");
				if($check->num_rows() >=1 )
				{
					$this->session->set_flashdata('message_failed',"Sorry data already exist!");
					redirect('product');
					}
				else
				{
					
					$res = $this->model_product->insertData("product",$data_insert);
					if($res>=1)
					{
						$this->session->set_flashdata('message_success',"Data product has been successfully saved!");
						redirect('product');
						}
					
					}
				
				}
			
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	public function editProduct($id_product)
	{
		
			date_default_timezone_set('Asia/Jakarta');
			ini_set('memory_limit', '-1');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['add_product']=='yes')
			{
				
			$this->load->helper('form');
			$this->load->helper('url');
			$this->load->library('form_validation');
			$this->form_validation->set_rules('id_product','ID Product','required');
			$this->form_validation->set_rules('brand','Brand','required');
			$this->form_validation->set_rules('product_code','Product Code','required');
			$this->form_validation->set_rules('category','Category','required');
			$this->form_validation->set_rules('product_name','Product Name','required');
			$this->form_validation->set_rules('product_name_front','Product Name Front End','required');
			$this->form_validation->set_rules('unit','Unit','required');
			$this->form_validation->set_rules('price_cs','Price cs','required');
			$this->form_validation->set_rules('price_pcs','Price pcs','required');
			$this->form_validation->set_rules('type_motorist','Type Motorist','required');
			
			if($this->form_validation->run()==FALSE){
			
			$check_product = $this->model_product->getProduct("WHERE id_product = '".$id_product."' ");
			if($check_product->num_rows() >=1)
			{	
			$data_product = $check_product->result_array();	
			$data = array (
				"id_product" => $data_product[0]['id_product'],
				"brand" => $data_product[0]['brand'],
				"product_code" => $data_product[0]['product_code'],
				"category" => $data_product[0]['category'],
				"sku" => $data_product[0]['sku'],
				"sku_front_end" => $data_product[0]['sku_front_end'],
				"unit" => $data_product[0]['unit'],
				"price_cs" => $data_product[0]['price_cs'],
				"price_pcs" => $data_product[0]['price_pcs'],
				"type" => $data_product[0]['type']
			
			);
			
			
			
					$comp = array(
						
						'title' => ' Edit Product',
						'content' => $this->load->view('edit-product',$data,true),
						'sidebar' => $this->html_sidebar()
					);
					
					$this->load->view("common/common",$comp);
			}
			else
			{
			
			}
				
			
			}
			
			else
			{
				// Get Variable Post
				$id_product = $_POST['id_product'];
				$brand = $_POST['brand'];
				$product_code = $_POST['product_code'];
				$category = $_POST['category'];
				$product_name = $_POST['product_name'];
				$product_name_front = $_POST['product_name_front'];
				$unit = $_POST['unit'];
				$price_cs = $_POST['price_cs'];
				$price_pcs = $_POST['price_pcs'];
				$type_motorist = $_POST['type_motorist'];
				
				$data_update = array(
				
				"category" => $category,
				"brand" => $brand,
				"sku" => $product_name,
				"sku_front_end" => $product_name_front,
				"unit" => $unit,
				"price_cs" => $price_cs,
				"price_pcs" => $price_pcs,
				"type" => $type_motorist

				);
				
				$where = array("id_product"=>$id_product);
				
				
				
					//Update Product
					$res = $this->model_product->UpdateData("product",$data_update,$where);
					if($res>=1)
					{
						$this->session->set_flashdata('message_success',"Data product has been successfully updated!");
						redirect('product');
						
						}
					else
					{
						$this->session->set_flashdata('message_failed',"Data product failed to update!");
						redirect('product');
					}
				
				
				
				
				
				//Check Product Apakah sudah ada dengan kode produk dan type motorist yang sama
			}
			
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	
	public function deleteProduct($id_product)
	{
		
			date_default_timezone_set('Asia/Jakarta');
			ini_set('memory_limit', '-1');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['delete_product']=='yes')
			{
				
			$this->load->helper('form');
			$this->load->helper('url');
			$this->load->library('form_validation');
			$this->form_validation->set_rules('id_product','ID Product','required');
			
			if($this->form_validation->run()==FALSE){
			
			$check_product = $this->model_product->getProduct("WHERE id_product = '".$id_product."' ");
			if($check_product->num_rows() >=1)
			{	
			$data_product = $check_product->result_array();	
			$data = array (
				"id_product" => $data_product[0]['id_product'],
				"brand" => $data_product[0]['brand'],
				"product_code" => $data_product[0]['product_code'],
				"category" => $data_product[0]['category'],
				"sku" => $data_product[0]['sku'],
				"unit" => $data_product[0]['unit'],
				"price_cs" => $data_product[0]['price_cs'],
				"price_pcs" => $data_product[0]['price_pcs'],
				"type" => $data_product[0]['type']
			
			);
			
			
			
					$comp = array(
						
						'title' => ' Delete Product',
						'content' => $this->load->view('delete-product',$data,true),
						'sidebar' => $this->html_sidebar()
					);
					
					$this->load->view("common/common",$comp);
			}
			else
			{
			
			}
				
			
			}
			
			else
			{
				// Get Variable Post
				$id_product = $_POST['id_product'];
				$where = array("id_product" => $id_product);
				
		
					//Update Product
					$res = $this->model_product->DeleteData("product",$where);
					if($res>=1)
					{
						$this->session->set_flashdata('message_success',"Data product has been successfully deleted!");
						redirect('product');
						
						}
					else
					{
						$this->session->set_flashdata('message_failed',"Data product failed to delete!");
						redirect('product');
					}
				
				
				
				
				
				//Check Product Apakah sudah ada dengan kode produk dan type motorist yang sama
			}
			
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	public function importProduct()
	{
		
			date_default_timezone_set('Asia/Jakarta');
			ini_set('memory_limit', '-1');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['import_product']=='yes')
			{
				
			$this->load->helper('form', 'html', 'file');
			$this->load->helper('url');
			$this->load->library('form_validation');
		
			
			
					
					$data = array ("");
					$comp = array(
						
						'title' => ' Import Product',
						'content' => $this->load->view('import-product',array('data'=>$data),true),
						'sidebar' => $this->html_sidebar()
					
					);
					
					$this->load->view("common/common",$comp);
					
	
			
		
			
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	public function doImportProduct()
	{
		
			date_default_timezone_set('Asia/Jakarta');
			ini_set('memory_limit', '-1');
			
			if ($this->tank_auth->is_logged_in()) {
			$user	= $this->tank_auth->get_username();
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			$user_role = $data_account[0]['user_type'];
			$code_role = $data_account[0]['code'];
			
			if($data_role[0]['import_product']=='yes')
			{
				
				
			if ($_POST) {
			ini_set('memory_limit', '-1');
		    $fileName = $_FILES['import']['name'];
			$config['upload_path'] = './files/';
			$config['file_name'] = $fileName;
			$config['allowed_types'] = 'xls|xlsx';
			$config['max_size']		= 100000000;

			$this->load->library('upload');
			$this->upload->initialize($config);

			if(! $this->upload->do_upload('import') )
			{
				$this->session->set_flashdata('message_failed','Import Failed, Please upload file excel extension!');
				redirect('product');
				
				
			}
			else
			{

			$media = $this->upload->data('import');
			
			$inputFileName = './files/'.$media['file_name'];

			//  Read your Excel workbook
			try {
				$inputFileType = IOFactory::identify($inputFileName);
				$objReader = IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
			} catch(Exception $e) {
				die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
			}

			//  Get worksheet dimensions
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow();
			$highestColumn = $sheet->getHighestColumn();

			//  Loop through each row of the worksheet in turn
			for ($row = 2; $row <= $highestRow; $row++){  				//  Read a row of data into an array 				
                        $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
												NULL,
												TRUE,
												FALSE);
												
												
				
				
			
					//jika master data tidak kosong maka akan diisi		
					$check = $this->model_product->getProduct("WHERE product_code = '".$rowData[0][2]."' AND type = '".$rowData[0][8]."' ");
					if($check->num_rows() >=1 )
					{
						
						$data_update = array(
							"category" => $rowData[0][0],
							"brand" => $rowData[0][1],
							"sku" => $rowData[0][3],
							"sku_front_end" => $rowData[0][4],
							"unit" => $rowData[0][5],
							"price_cs" => $rowData[0][6],
							"price_pcs" => $rowData[0][7]
							
						);
						$where = array(
							"product_code" => $rowData[0][2],
							"type" => $rowData[0][8]
						);
						
						$res = $this->model_product->UpdateData("product",$data_update,$where);
					
						}
					else
					{
						$data_insert = array(
							"category" => $rowData[0][0],
							"brand" => $rowData[0][1],
							"product_code" => $rowData[0][2],
							"sku" => $rowData[0][3],
							"sku_front_end" => $rowData[0][4],
							"unit" => $rowData[0][5],
							"price_cs" => $rowData[0][6],
							"price_pcs" => $rowData[0][7],
							"type" => $rowData[0][8]
							
						);
						
						//Insert Data
						$res = $this->model_product->insertData("product",$data_insert);
					
					}
					
				
				
			}
				@unlink($inputFileName);
				$this->session->set_flashdata('message_success','Data imported successfully');
				redirect('product');
			
               
			}
			
			 	
            }
		
			
			}
		else
		{
			$data = "You dont have permission to access this page";
			$comp = array(
			
			'title' => ' Permission Denied',
			'content' => $this->load->view('accessdenied',array('data'=>$data),true),
			'sidebar' => $this->html_sidebar()
			);
			$this->load->view("common/common",$comp);
			
			}
			
		}
		else
		{
			redirect('/auth/login/');
			}
		
	}
	
	
	
	
	
	public function exportProduct()
	{
		
		date_default_timezone_set('Asia/Jakarta');
		if ($this->tank_auth->is_logged_in()) {
		$user	= $this->tank_auth->get_username();
			
		$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
		$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
		
		if($data_role[0]['see_product']=='yes')
		{
			
		$date = date("m-d-Y");
		$query = $this->db->get('product');
        if(!$query)
        return false;
 
        // Starting the PHPExcel library
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');
 
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("export")->setDescription("none");
		
 
        $objPHPExcel->setActiveSheetIndex(0);
 		$objPHPExcel->getActiveSheet()->setShowGridlines(false);
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		
		$Fontstyle = array(
		'font'  => array(
			'bold'  => true,
			'color' => array('rgb' => 'ffffff')
		));
		
		$FontstyleTitle = array(
		'font'  => array(
			'bold'  => true,
			'color' => array('rgb' => '000000'),
			'size' => 15
		));
		
		$styleAlign = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    	);
		
		//Set Width Column
		foreach(range('B','Z') as $columnID)
		{
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		
		
		$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, 1, "Master Product");
		//Merge And Center Title
		$objPHPExcel->getActiveSheet()->mergeCells('A1:D1');
		
		$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, 2, "Date : ".$date);
		
		//Merge And Center Date
		$objPHPExcel->getActiveSheet()->mergeCells('A2:D2');
		
		//Set Font Color Title
		$objPHPExcel->getActiveSheet()->getStyle('A1:D2')->applyFromArray($FontstyleTitle);
		
		//Set Font Color Header
		$objPHPExcel->getActiveSheet()->getStyle('B4:K4')->applyFromArray($Fontstyle);
		
		//Set Backgroung Color Header
		$objPHPExcel->getActiveSheet()->getStyle('B4:K4')->applyFromArray(
			array(
				'fill' => array(
					'type' => PHPExcel_Style_Fill::FILL_SOLID,
					'color' => array('rgb' => '#62a8ea')
				)
			)
		);


		
        // Field names in the first row
         // Field names in the first row
        $fields = array(
		
		"No" => "No",
		"Category" => "Category",
		"Brand" => "Brand",
		"Product Code" => "Product Code",
		"SKU" => "SKU",
		"SKU Front End" => "SKU Front End",
		"Unit" => "Unit",
		"Price Cs" => "Price Cs",
		"Price Pcs" => "Price Pcs",
		"Motorist Type" => "Motorist Type"
		
		);
        $col = 1;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 4, $field);
            $col++;
        }
		
		
		

 
        // Fetching the table data
        $row = 5;
		$no = 1;
        foreach($query->result_array() as $data)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $row, $no);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $row, $data['category']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $row, $data['brand']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $row, $data['product_code']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $row, $data['sku']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $row, $data['sku_front_end']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $row, $data['unit']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $row, $data['price_cs']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $row, $data['price_pcs']);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $row, $data['type']);
 
            $row++;
			$no++;
        }
		
	   $last_row = $row-1;
	   //Set Border
       $objPHPExcel->getActiveSheet()->getStyle("B4".":"."K".$last_row)->applyFromArray($BStyle);
	   $objPHPExcel->getActiveSheet()->getStyle("B4".":"."K".$last_row)->applyFromArray($styleAlign);
       $objPHPExcel->setActiveSheetIndex(0);
 
        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');
 		
		
	   // Sending headers to force the user to download the file
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Master-Product-'.$date.'.xls"');
        header('Cache-Control: max-age=0');
        $objWriter->save('php://output');
		
			}
			else
			{
				$data = "You dont have permission to access this page";
				$comp = array(
			
				'title' => ' Permission Denied',
				'content' => $this->load->view('accessdenied',array('data'=>$data),true),
				'sidebar' => $this->html_sidebar()
				);
				$this->load->view("common/common",$comp);
			
				}
			
			}
		else
		{
			redirect('/auth/login/');
			}
			
		}
	
	
	
	
	
	public function html_sidebar()
	{
		
		if (!$this->tank_auth->is_logged_in()) {
			redirect('/auth/login/');
		} else {
			$user	= $this->tank_auth->get_username();
			
			$data_account = $this->model_account_master->getAccount("WHERE username = '".$user."' ")->result_array();
			$data_role = $this->model_account_master->getRole("WHERE id_role = '".$data_account[0]['user_access']."' ")->result_array();
			return $this->load->view("common/sidebar_admin",array('data_account'=>$data_account,'data_role'=>$data_role),true);
		}
	}
	
}

/* End of file dashboard.php */
/* Location: ./application/controllers/admin/dashboard.php */